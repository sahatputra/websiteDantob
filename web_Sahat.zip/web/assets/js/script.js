var tutorial1 = document.getElementById("lead-1");
tutorial1.innerText = "Skills:";

var paragraf = document.getElementsByClassName("lead");
    setInterval(function () {
        paragraf[0].style.color = "green";
        paragraf[1].style.color = "blue";
        paragraf[2].style.color = "cyan";
        paragraf[5].style.color = "cyan";
        paragraf[4].style.color = "blue";
        paragraf[3].style.color = "green";

        setTimeout(function () {
            paragraf[0].style.color = "grey";
            paragraf[1].style.color = "grey";
            paragraf[2].style.color = "grey";
            paragraf[3].style.color = "grey";
            paragraf[4].style.color = "grey";
            paragraf[5].style.color = "grey";
        }, 500)

    }, 1000);